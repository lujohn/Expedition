/**
 * Created by johnlu on 3/3/17.
 */
'use strict'

angular.module('expeditionApp', ['ui.router', 'ngAnimate'])
.config( function ($stateProvider) {

	$stateProvider.state('mainMenu', {
		url: '',
		templateUrl: 'views/main.html'
	});
});